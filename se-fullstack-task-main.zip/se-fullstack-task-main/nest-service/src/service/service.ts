import { Injectable } from "@nestjs/common";

@Injectable()
export class Service {
  constructor() {}

  async get(): Promise<any> {}
}
